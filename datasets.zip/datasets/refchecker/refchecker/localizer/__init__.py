from .embed_localizer import NaiveEmbedLocalizer
